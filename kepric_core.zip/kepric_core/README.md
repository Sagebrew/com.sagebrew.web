# Kepric Core #

Contains all of the information for getting a kepric based application up and running in a development environment.

### Installation ###
#### Instructions Mac####
##### New Project #####
1. In the primary directory of your git repository use the command `git submodule add git@github.com:Kepric/kepric_core.git`
2. Create your Django Project `django-admin.py startproject [your app]`
3. Create a directory named `requirements` that includes minimially a `base.txt` and `development.txt`
4. Create a folder labeled `settings` in the Django app you just created. There should be a `settings.py` file in this directory.
5. Create an `__init__.py` file in the folder (It can be empty for the time being)
6. Move the `settings.py` file into this directory.
7. It is recommmended that you create at least a `development.py` and `production.py` setting file in this directory but how you seperate your settings is up to you.
8. In the settings file that will be active during your development ensure there is a database configured in the following way:


	DATABASES = {
	    'default': {
	        'ENGINE': 'django.db.backends.postgresql_psycopg2',
	        'NAME': '[name-of-app]_db',
	        'USER': 'admin',
	        'PASSWORD': 'admin',
	        'HOST': 'localhost',
	        'PORT': '',
	    }
	}


9. Follow steps located under "New Installation of Existing Project"


##### New Installation of Existing Project #####
1. Navigate to `[project_directory]/kepric_core/`
2. Prior to continuing if you would like to use your own ssl certificates please note that you can follow step 5 prior to 3 and not have to execute step 6.
3. Run `python setup.py install`
4. At the end of the installation you should see the the Django debugger running in the terminal and you should be able to access the site at https://192.168.56.101/
5. If you would like to use verified ssl certificates for development place your verified wildcard certificates into the directory named `certs` in the parent directory of your repo (the one that contains the kepric_core folder). Note that if you are performing this step prior to step 3 the certs folder will not exist. If you are doing this after running step three replace the following files (must use same naming or manually edit nginx files to match new naming):
     * cert.pem (if you have a bundled cert append it to the bottom of your public certification. See [instructions](http://blog.robodomain.com/post/3698910833/godaddy-ssl-certificates-and-nginx) if you have issues)
	 * key.pem
6. If you end up replacing the certificate and key after running step 3 then you will have to manually restart nginx (a new command is being developed to automate this process but is not in place yet). This can be accomplished by:
     * `vagrant ssh`
	 * `sudo service nginx stop`
	 * `sudo service nginx reload`
	 * `sudo service nginx restart`
	 * `exit`
7. After placing your certificates and keys in that directory use your domain manager or edit your hosts file to point local.[your domain name] to 192.168.56.101. 


##### Upgrading Installation #####
If you are upgrading you should run the following commands from within the kepric_core directory if you are in your virtual environment:

1. `fab destroy_env`
2. `deactivate`
3. `python setup.py install`

If your virtual environment is not active you should run the following commands from within the kepric_core directory:

1. `vagrant destroy`
2. `rm -r venv/`
3. `rm -r .vagrant`
4. `deactivate`
5. `python setup.py install`

#####Notes#####
###### .gitignore & certs ######
Your .gitignore file will be automatically updated to ignore your private key (key.pem) but will store the certs since they are primarly public. If this is not what you want please update your .gitignore after the initial installation.

Keep in mind that this means anyone setting up a development environment will need to have the key placed on their system via another process. Please keep your key out of your source control system though as that would create a large security risk.

If you leave the original certificate and key in the certs folder the key associated with the certificate can be found in `kepric_core/self_signed_certs/` if you should need it in someone's environment that did not run the initial `python setup.py install` command.

###### Initializing Kepric Core ######
If you navigate to `[project_directory]/kepric_core/` and don't see anything in the directory run `git submodule update --init`.

###### Username & Password ######
Your username and password for the administrator interface will be admin
after the setup has completed.

#### Instructions Windows ####
This process has only been tested on Windows 7 but should also work for Windows XP, Vista, and 8. Also to note if you are using windows will have no access to the commands listed below. To gain access to them you will need to go through the process of getting Fabric installed on a Windows machine which we have not yet gone through the trouble of doing. A set of the commands can be run locally on the VM after it is launched and is what we recommend doing.

##### Installing an Existing Environment #####
1. Install the latest version of [Virtual Box](https://www.virtualbox.org/wiki/Downloads)
2. Install the latest version of [Vagrant](http://www.vagrantup.com/downloads.html)
3. Install the latest version of [Git](http://git-scm.com/downloads)
4. If you need a way to pull down the repo you would like to work on, download the latest [GitHub Client](http://windows.github.com)
5. Clone the repository you would like to work on into your local machine.
6. Right click on your desktop
7. Select `Git Bash`
8. Navigate to the directory you cloned the repository into (keep in mind the terminal opened by `Git Bash` is closer to a Unix terminal than a windows one).
9. Navigate into the `kepric_core` directory within the repository.
10. Execute the following commands:
11. `vagrant up` (If you are prompted with a question regarding choosing a network connection, choose the one you would like the VM to access the network on)
12. `vagrant ssh`
13. `source /home/venv/bin/activate`
14. `pip install setuptools --no-use-wheel --upgrade`
15. `pip install --exists-action=w -r /home/apps/kepric_core/requirements/development.txt`
16. `pip install --exists-action=w -r /home/apps/requirements/development.txt`
17. If there isn't a directory `/home/apps/certs/` then create one and copy `cert.pem` and `key.pem` from `/home/apps/kepric_core/self_signed_certs/`
18. `cd /home/apps/kepric_core`
19. `fab improve_grub_settings`
20. If `certs/key.pem` is not already in you .gitignore file you should add it
21. `fab install_nginx_dev:"192.168.56.101"`
22. `createdb [project_name]_db -h localhost -U admin`
23. If prompted use `admin` for password
24. If you receive an error about authentication failing do the following:
    * `sudo passwd postgres`
    * Enter the password you want for postgres
	* `su postgres` (Use the password you just created)
	* `createuser -P -s -e admin`
	* `exit`
	* Rerun step 22.
25. `cd /home/apps/[name_of_project]/`
26. `python manage.py syncdb --no-initial-data`
27. When prompted on if you would like to create a user enter `yes`
28. Use `admin` for the username, `admin@example.com` for the email, and `admin` for the password.
29. `python manage.py migrate --no-initial-data`
30. `cd /home/apps/kepric_core/`
31. `fab collect_static_files`
32. `cd /home/apps/[project_name]/`
33. `python manage.py syncdb --migrate`
34. `python manage.py validate`
35. `python manage.py runserver 0.0.0.0:8080`
36. If you receive any database errors or cannot access the site at https://192.168.56.101 then ensure postgres and nginx are running using `sudo service postgresql start` and `sudo service nginx restart`


#### Shortcut Commands ####
To help expediate development some common processes have been packaged into single fabric commands that can be executed from your local machine to control the development VM. To gain access to these commands enter `source venv/bin/activate` into your command line from the `kepric_core` directory. Note that these commands must be run from the `kepric_core` directory or issues may occur. 

The commands and their functionality can be found below.

*  `fab clear_db`
  * clear_db is used for replacing the database. It drops the existing one and creates one in its place. It then runs through syncdb, migrate, validate, and if all goes smoothly it starts up your development server again.
  * This should be used if you make modifications to your models and want to update the database without making migration files. 
  *  Note that this command should be used over just using syncdb to update your database after model changes. syncdb is being depricated as of Django 1.7 and its functionality is finally being merged with migrate. If you just run syncdb without removing the db or appending some flags the modifications you made to your models may not show up in the database unless you've created a completely new model.
*  `fab clear_db_only`
  * `clear_db_only` is the same as `clear_db` only it doesn't start up a new server. This command exists so that if you want to run two terminals and update the database without restarting yoru server you can.
*  `fab start_dev`
  * start_dev is used after the initial setup has completed and you had stopped the development server for some reason. `fab start_dev` can be used to:
    * Resume the development server after `ctrl + c` was pressed to kill another fabric command.
	* Resume the development server after `vagrant suspend` has been run.
	* Resume the development server after `fab suspend` has been run.
	* Updates the installed applications based on the requirements listed in:
	  ** `[project_path]/requirements/base.txt` 		                	  		** `[project_path]/requirements/development.txt`
  * Note that start_dev should not be used to initialize the virtual machine
  * Note that this command will not delete the data currently in the database. If you run into issues where you are not seeing the updates of the packages reflected in the models, first ensure that if the package needs to be included in INSTALLED_APPS in your settings that you added it there. If you have and it still isn't showing up try `fab clear_db`. If this doesn't work please post an issue.
* `fab update_reqs`
  * update_reqs provides an easy way to update the requirements on the virtual machine after you have changed requirements in either `[project_path]/requirements/base.txt` or  `[project_path]/requirements/development.txt`. This command will use pip to install the new packages, update the database schema for you and restart the development server.
  * Note that this command will not delete the data currently in the database. If you run into issues where you are not seeing the updates of the packages reflected in the models, first ensure that if the package needs to be included in INSTALLED_APPS in your settings that you added it there. If you have and it still isn't showing up try `fab clear_db`. If this doesn't work please post an issue.
* `fab install_vagrant`
  * install_vagrant is initially executed during the `python setup.py install` process. It should only be used if you've executed `python setup.py install` and then ran `vagrant destroy` or `fab destroy`.
  * This command assumes it is dealing with a clean VM and will attempt to install all of the base packages as well as setup your application as if doing so for the first time.
  * This command is handy if your VM has become corrupted for some reason and you need a fresh one created. If so run `fab destroy` then this command.
* `fab dumpdata`
  * dumpdata can be used to generate a JSON fixture of the current database instance.
  * dumpdata will store the JSON fixuture in the project directory (the one with manage.py in it) with the name temp.json.

Each of the commands above, except `fab install_vagrant` has a local version that can be used to execute the same functionality on the local system. These commands can be accessed by appending `_local` to the end of the remote commands. For example to execute clear_db locally run `fab clear_db_local`. These local commands exist incase you need to run a development environment locally on your machine without a VM for some reason.


#### Management Commands ####
Along with the shortcut commands come standard management commands that can be used to manage the state of the VM. To gain access to these commands enter `source venv/bin/activate` into your command line from the `kepric_core` directory. Note that these commands must be run from the `kepric_core` directory or issues may occur. 

The commands and their functionality can be found below.

* `fab suspend`
  * suspend is the equivelant to executing `vagrant suspend` but should be used in its place because additional clean-up functionality may be added. 
  * supsend is what should be used if you no longer are using the VM and would like to pause it.
  * This should be used anytime you are done developing or are moving over to another project that does not need this VM to function. Otherwise certain resources might be utilized by this VM that the other needs.
* `fab destroy`
  * destroy is the equivelant to executing `vagrant destroy` but should be used in its place because additional clean-up functionality may be added.
  * destroy is what should be used if you want to completely destroy a VM. This is usually needed if the VM has become corrupted for some reason.
* `fab halt`
  * halt is the equivelant to executing `vagrant halt` but should be used in its place because additional clean-up functionality may be added.
  * halt is what should be used if you want to shut down the VM instead of just pausing it. This can be interchanged with suspend but will result in a full VM shutdown.


 
#### Potential Issues ####
##### Mac OS X 10.9 #####
###### VirtualBox Issue ######
Occasionally when executing `python setup.py install` you may receive an error that looks like the following:

```
There was an error while executing `VBoxManage`, a CLI used by Vagrant
for controlling VirtualBox. The command and stderr is shown below.

Command: ["hostonlyif", "create"]

Stderr: 0%...
Progress state: NS_ERROR_FAILURE
VBoxManage: error: Failed to create the host-only adapter
VBoxManage: error: VBoxNetAdpCtl: Error while adding new interface: failed to open /dev/vboxnetctl: No such file or directory

VBoxManage: error: Details: code NS_ERROR_FAILURE (0x80004005), component HostNetworkInterface, interface IHostNetworkInterface
VBoxManage: error: Context: "int handleCreate(HandlerArg*, int, int*)" at line 68 of file VBoxManageHostonly.cpp

Fatal error: local() encountered an error (return code 1) while executing 'vagrant up'

Aborting.
```

If you receive this error then run the following command:

`sudo /Library/StartupItems/VirtualBox/VirtualBox restart`

This is the default location where VirtualBox is installed on OS X but 
if this does not work your VirtualBox might have been moved in which case
use the updated path.


###### Timeout Issue ######
Occassionally you may also see an error that looks like the following:

`URLError: <urlopen error _ssl.c:489: The handshake operation timed out>`

If this error shows up in the terminal then the VM was having difficulty reaching the internet and the system timedout on installing some of the necessary packages.

To fix this run:

```
$ fab destroy
$ fab install_vagrant
```

This will delete the corrupted instance and reinstall the VM. If it continues to fail wait a couple minutes and try again. If this does not work there might be an issue with your network setup.


###### Bus Error ######
If you are on a computer with limited resources or have multiple applications
running when you execute this command you may run into a Bus error. This
occurs if there is a problem communicating or updating the VM. This will crash the Vagrant installation and result in a corrupted VM.

To fix it run:

```
$ fab destroy
$ fab install_vagrant
```

Like with the timeout issue this will delete the corrupted instance and reinstall the VM. If this continues to happen please restart you computer and attempt to run the installation while less processes are active. Running `sudo /Library/StartupItems/VirtualBox/VirtualBox restart` may also help in resolving the issue if you are unable to restart your computer.


###### Running State Error ######
Sometimes after restarting your hardware VirtualBox's background services can fail to startup at bootup. This can cause the following error to be shown when you try to bring back up the development environment:

```
The VM failed to remain in the "running" state while attempting to boot.
This is normally caused by a misconfiguration or host system incompatibilities.
Please open the VirtualBox GUI and attempt to boot the virtual machine
manually to get a more informative error message.
```

If this happens use `sudo /Library/StartupItems/VirtualBox/VirtualBox restart` to restart VirtualBox's services. This should resolve the issue.


### Notes ###
* You can close down the server with ctrl + c


### Issues ###
This package is a work in progress and has not been tested in every situation. If you find a bug or would like additional commands added please create a ticket on this project's [Issue Panel](http://jira.pushdisplay.com/browse/KC#selectedTab=com.atlassian.jira.plugin.system.project%3Aissues-panel). We will do our best to get bug fixes out as soon as possible.