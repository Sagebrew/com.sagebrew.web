from os import walk
from os.path import isdir, exists
 
from distutils.sysconfig import get_python_lib
from subprocess import call
from getpass import getuser
import multiprocessing
 
from fabric.api import env, local, run, hide, settings
from unipath import Path
 
PROJECT_DIR = Path(__file__).ancestor(2)
cd_command_gen = lambda cd_command: "cd %s/kepric_core/ && " % cd_command
 
 
"""
Internal functions. these are used by the other user run functions to enable
them to function correctly.
"""
 
 
def determine_thread_count():
    cpu_count = multiprocessing.cpu_count()
    thread_count = (2 * cpu_count) + 1
    return thread_count
 
 
def vagrant():
    env.user = 'vagrant'
    result = dict(line.split() for line in local('vagrant ssh-config',
                                                    capture=True).splitlines())
    env.hosts = ['%s:%s' % (result['HostName'], result['Port'])]
    env.key_filename = result['IdentityFile']
    env.password = "admin"
 
 
def get_manage_path(project_dir):
    project_info = {"project_path": "", "project_name": ""}
    ignore_list = ['build', '.git', '.vagrant', 'puppet']
    for (dirpath, dirnames, filenames) in walk(project_dir):
        if(any(ignore in dirpath for ignore in ignore_list)):
            continue
        elif("manage.py" in filenames and "project_template" not in dirpath):
            project_info['project_name'] = dirpath[dirpath.rfind('/') + 1:]
            project_info['repo_name'] = PROJECT_DIR[PROJECT_DIR.rfind('/')
                                                                        + 1:]
            project_info['project_path'] = dirpath
            break
    return project_info
 
 
def remote_project_path(project_dir):
    project_info = get_manage_path(project_dir)
    print project_info['project_path']
 
 
def remote_project_name(project_dir):
    project_info = get_manage_path(project_dir)
    print project_info['project_name']
 
 
def get_remote_project_path(working_dir):
    virt = "source /home/venv/bin/activate && "
    cd_command = cd_command_gen(working_dir)
    project_path = run(cd_command + virt + 'fab remote_project_path:%s'
                                                             % working_dir)
    return ' '.join(project_path.replace('Done.', '').split())
 
 
def get_remote_project_name(working_dir):
    virt = "source /home/venv/bin/activate && "
    cd_command = cd_command_gen(working_dir)
    project_name = run(cd_command + virt + 'fab remote_project_name:%s'
                                                             % working_dir)
    return ' '.join(project_name.replace('Done.', '').split())
 
 
def clear_db_commands(server, environ):
    from ilogue.fexpect import expect, expecting
    from ilogue import fexpect
    manage_info = get_manage_path(PROJECT_DIR)
    if(environ == "dev"):
        project_name = manage_info['project_name']
    else:
        project_name = manage_info['repo_name']
    project_name = project_name.replace('-', '_')
    prompts = []
    prompts += expect('Password:', 'admin')
    prompts += expect('Password:', 'admin')
    with(expecting(prompts)):
        project_name = project_name.replace("-", "_")
        fexpect.run('dropdb %s_db -h localhost -U admin' % project_name)
        fexpect.run('createdb %s_db -h localhost -U admin' % project_name)
    run_dev_db("/home/apps", server)
 
 
def run_dev_db(working_dir, server):
    admin_setup(working_dir)
    run_dev_remote_commands(server)
 
 
def run_dev_db_local():
    admin_setup_local()
    start_dev_local()
 
 
def run_dev_remote_commands(server):
    working_dir = '/home/apps'
    virt = "source /home/venv/bin/activate && "
    cd_command = "cd " + working_dir + "/kepric_core/ && "
    project_path = get_remote_project_path(working_dir)
    postgres_running = run("service postgresql status")
    postgres_clean = postgres_running.strip()
    if postgres_clean == "Running clusters:":
        run("sudo service postgresql start")
    with settings(warn_only=True):
        nginx_running = run("sudo service nginx status")
        nginx_clean = nginx_running.strip()
        if "could not access PID file for nginx" in nginx_clean:
            run("sudo service nginx restart")
 
        memcached = run("sudo service memcached status")
        memcached = memcached.strip()
        if(memcached != "* memcached is running"):
            memcached = run("sudo service memcached start")
 
    update_remote_venv()
    #run(cd_command + virt + "fab collect_static_files")
    run(virt + "python %s/manage.py validate" % project_path)
    if(server == "server"):
        run(virt + "python %s/manage.py runserver 0.0.0.0:8080" % project_path)
 
 
def get_allowed_hosts():
    from django.conf import settings
    allowed_hosts = ''
    count = 0
    for host in settings.ALLOWED_HOSTS:
        if(count == 0):
            allowed_hosts = host
        else:
            allowed_hosts = allowed_hosts + host + '|'
    if(allowed_hosts == '*'):
        allowed_hosts = '?<address>.+'
    return allowed_hosts
 
 
def execute_non_python_scripts():
    f = []
    execute_dir = "/home/apps/execute/"
    internal_lib_dir = "/home/apps/internal_libraries/"
    if isdir(execute_dir):
        for (dirpath, dirnames, filenames) in walk(execute_dir):
            f.extend(filenames)
            break
        file_paths = filter(lambda a: a[0] != ".", f)
        for item in file_paths:
            call("sh /home/apps/execute/%s" % item, shell=True)
    if isdir(internal_lib_dir):
        for (dirpath, dirnames, filenames) in walk(execute_dir):
            f.extend(filenames)
            break
        for item in f:
            call("cp -r /home/apps/internal_libraries/%s " \
                "/home/venv/lib/python2.7/site-packages/" % item, shell=True)
 
 
def dev_commands():
    from ilogue.fexpect import expect, expecting
    from ilogue import fexpect
    working_dir = '/home/apps'
    manage_info = get_manage_path(PROJECT_DIR)
    virt = "source /home/venv/bin/activate && "
    with hide('output'):
        run("sudo -E pip install pexpect")
        run(virt + "pip install setuptools --no-use-wheel --upgrade")
        run(virt + "pip install --exists-action=w -r" \
                " %s/kepric_core/requirements/development.txt" % working_dir)
 
    run("cd /home/apps/kepric_core && %s fab execute_non_python_scripts" %
                                                                         virt)
    run(virt + "pip install --exists-action=w -r" \
                " %s/requirements/development.txt" % working_dir)
    with hide('output'):

        certs_dir = "%s/certs/" % PROJECT_DIR
        cert_path = certs_dir + "cert.pem"
        key_path = certs_dir + "key.pem"
        if not isdir(certs_dir):
            local("mkdir %s" % certs_dir)
            if not exists(cert_path):
                local("cp %s/kepric_core/self_signed_certs/cert.pem "
                    % PROJECT_DIR + "%s/certs/cert.pem" % PROJECT_DIR)
            if not exists(key_path):
                local("cp %s/kepric_core/self_signed_certs/key.pem "
                    % PROJECT_DIR + "%s/certs/key.pem" % PROJECT_DIR)
 
    run('cd /home/apps/kepric_core && %s fab improve_grub_settings' % virt)
    gitignore_path = "%s/.gitignore" % PROJECT_DIR
    with open(gitignore_path, "r+") as gitignore_file:
        ignore_contents = gitignore_file.read()
        certs_ignore = "certs/key.pem\n"
        if certs_ignore not in ignore_contents:
            gitignore_file.write(certs_ignore)
    project_name = manage_info['project_name']
    run(cd_command_gen(working_dir) + virt +
            'fab install_nginx_dev:"192.168.56.101"')
    prompts = []
    prompts += expect('Password:', 'admin')
    with(expecting(prompts)):
        fexpect.run('createdb %s_db -h localhost -U admin' % project_name)
    admin_setup(working_dir)
    run_dev_remote_commands("server")
 
 
def get_db_json():
    virt = "source /home/venv/bin/activate && "
    working_dir = '/home/apps'
    project_path = get_remote_project_path(working_dir)
    cd_command = "cd %s && " % (project_path)
    run(virt + cd_command + "python manage.py dumpdata > temp.json")
 
def prep_admin_setup_responses():
    from ilogue.fexpect import expect
    admin_setup = []
    admin_setup += expect('Would you like*', 'yes')
    admin_setup += expect("Username*", 'admin')
    admin_setup += expect("Email*", 'admin@example.com')
    admin_setup += expect("Password*", 'admin')
 
    return admin_setup
 
 
def admin_setup(working_dir):
    from ilogue.fexpect import expecting
    from ilogue import fexpect
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['project_name']
    virt = "source /home/venv/bin/activate && "
    cd_command = "cd %s/%s && " % (working_dir, project_name)
    admin_setup = prep_admin_setup_responses()
 
    with(expecting(admin_setup)):
        fexpect.run(virt + cd_command + "python manage.py syncdb")
 
 
def admin_setup_local():
    manage_info = get_manage_path(PROJECT_DIR)
    project_path = manage_info['project_path']
    cd_command = "cd %s && " % project_path
 
    local(cd_command + "python manage.py syncdb")
 
 
def update_remote_venv():
    working_dir = '/home/apps'
    virt = "source /home/venv/bin/activate && "
    with hide('output'):
        run(virt + "pip install --exists-action=w -r" \
                " %s/kepric_core/requirements/development.txt" % working_dir)
    run(virt + "pip install --exists-action=w -r" \
                " %s/requirements/development.txt" % working_dir)
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['project_name']
    cd_command = "cd /home/apps/%s && " % project_name
    run(virt + cd_command + "python manage.py syncdb")
 
 
def populate_gunicorn_script_local():
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['project_name']
    project_path = manage_info['project_path']
    enviro = [get_python_lib()][0]
    thread_count = "%d" % determine_thread_count()
    f = open("gunicorn_start.tmpl", "r")
    file_string = f.read()
    f.close()
 
    enviro_path = enviro.replace('lib/python2.7/site-packages', "bin/activate")
    file_string = file_string.replace('[[project_name]]', project_name)
    file_string = file_string.replace('[[project_path]]', project_path)
    file_string = file_string.replace('[[virtual_env]]', enviro_path)
    file_string = file_string.replace('[[username]]', getuser())
    file_string = file_string.replace('[[thread_count]]', thread_count)
    gunicorn_script = "%s/gunicorn_start.bash" % project_path
 
    f = open(gunicorn_script, "w")
    f.write(file_string)
    f.close()
    call("chmod u+x %s" % gunicorn_script, shell=True)
 
 
def populate_supervisor_conig_local():
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['repo_name']
    project_path = manage_info['project_path']
    f = open("supervisor_conf.tmpl", "r")
    file_string = f.read()
    f.close()
 
    file_string = file_string.replace('[[project_name]]', project_name)
    file_string = file_string.replace('[[project_path]]', project_path)
    file_string = file_string.replace('[[username]]', getuser())
    call("sudo chown %s /etc/supervisor/conf.d/" % getuser(), shell=True)
    supervisor_config = "/etc/supervisor/conf.d/%s.conf" % project_name
 
    f = open(supervisor_config, "w")
    f.write(file_string)
    f.close()
 
def improve_grub_settings():
    call('sudo chown vagrant /etc/default/grub', shell=True)
    call('echo "GRUB_RECORDFAIL_TIMEOUT=0" >> /etc/default/grub',
            shell=True)
    call("echo GRUB_DISABLE_RECOVERY=" + """'"'true'"'""" + \
        " >> /etc/default/grub", shell=True)
 
    header_path = '/etc/grub.d/00_header'
    call("sudo chown %s %s" % (getuser(), header_path), shell=True)
    header_file = open(header_path, "r+")
    header_string = header_file.read()
 
    header_string = header_string.replace('set timeout=-1', 'set timeout=0')
    header_file.write(header_string)
    header_file.close()
 
    grub_linux_path = '/etc/grub.d/10_linux'
    call("sudo chown %s %s" % (getuser(), grub_linux_path), shell=True)
    grub_file = open(grub_linux_path, "r+")
    grub_array = grub_file.readlines()
    grub_array[187] = '  set linux_gfx_mode=keep\n'
    grub_file.writelines(grub_array)
    grub_file.close()
 
 
    call('sudo update-grub', shell=True)
 
 
def install_supervisor():
    call("sudo apt-get -y install supervisor", shell=True)
 
 
def install_nginx(domain, template, server):
    call("sudo apt-get -y install nginx", shell=True)
    populate_nginx_config(domain, template, server)
    configure_nginx()
    nginx_populate_base_conf()
    call("sudo service nginx reload", shell=True)
    call("sudo service nginx stop", shell=True)
    call("sudo service nginx start", shell=True)
 
 
def install_nginx_dev(domain):
    template = "nginx_templates/development.tmpl"
    install_nginx(domain, template, 'dev')
 
 
def install_nginx_stage(domain):
    template = "nginx_templates/production.tmpl"
    install_nginx(domain, template, 'prod')
 
def populate_nginx_config(domain, template, server):
    '''
    investigate using get_allowed_hosts to replace domains rather
    than a passed value. Don't know which is better. Cause might
    want to populate settings with domain as well and just be
    consistent for sure.
    '''
    nginx_dir = "/etc/nginx"
    available = "%s/sites-available/" % nginx_dir
    enabled = "%s/sites-enabled/" % nginx_dir
    manage_info = get_manage_path(PROJECT_DIR)
    if(server == 'dev'):
        project_name = manage_info['project_name']
    else:
        project_name = manage_info['repo_name']
    project_path = manage_info['project_path']
 
    app_conf = open(template, "r")
    app_string = app_conf.read()
    app_conf.close()
 
    app_string = app_string.replace('[[project_name]]', project_name)
    app_string = app_string.replace('[[project_path]]', project_path)
    app_string = app_string.replace('[[project_dir]]', PROJECT_DIR)
    app_string = app_string.replace('[[server_name]]', domain)
 
    call("sudo chown %s /etc/nginx/sites-available/" % getuser(), shell=True)
 
    nginx_config = "/etc/nginx/sites-available/%s.nginxconf" % project_name
    app_file = open(nginx_config, "w")
    app_file.write(app_string)
    app_file.close()
 
    call("sudo ln -s %s%s.nginxconf %s%s.nginxconf" % (available, project_name,
                                            enabled, project_name), shell=True)
 
 
def nginx_populate_base_conf():
    base_conf_dir = "/etc/nginx/conf.d/"
    base_conf = "%sbase.nginxconf" % base_conf_dir
    base_conf_tmpl = "nginx_templates/base.tmpl"
    call("sudo chown %s %s" % (getuser(), base_conf_dir), shell=True)
 
    base_conf_tmpl_file = open(base_conf_tmpl, "r")
    base_conf_tmpl_string = base_conf_tmpl_file.read()
    base_conf_tmpl_file.close()
 
    base_conf_tmpl_string = base_conf_tmpl_string.replace('[[username]]',
                                                            getuser())
    base_conf_tmpl_string = base_conf_tmpl_string.replace(
                                            '[[worker_processes]]',
                                            '%d' % multiprocessing.cpu_count())
    base_conf_file = open(base_conf, "w")
    base_conf_file.write(base_conf_tmpl_string)
    base_conf_file.close()
    call("sudo chown root %s" % (base_conf_dir), shell=True)
 
 
def configure_nginx():
    nginx_config = "/etc/nginx/nginx.conf"
    call("sudo chown %s %s" % (getuser(), nginx_config), shell=True)
    base_conf_tmpl = "nginx_templates/nginx.tmpl"
    nginx_template = open(base_conf_tmpl, "r")
    file_string = nginx_template.read()
    nginx_template.close()
 
    f = open(nginx_config, "w")
    f.write(file_string)
    f.close()
    call("sudo chown root %s" % (nginx_config), shell=True)
 
 
def instantiate_log_files():
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['repo_name']
    call("mkdir -p /home/apps/logs/%s/" % project_name, shell=True)
    call("touch /home/apps/logs/%s/gunicorn_supervisor.log" % project_name,
                                                                shell=True)
 
 
def collect_static_files():
    manage_info = get_manage_path(PROJECT_DIR)
    project_path = manage_info['project_path']
    enviro = [get_python_lib()][0]
    enviro_path = enviro.replace('lib/python2.7/site-packages', "bin/python")
    call("%s %s/manage.py collectstatic --noinput" % (enviro_path,
                                                project_path), shell=True)
 
'''
Commands used to manipulate the development VM. (Vagrant box)
'''
 
 
def clear_db():
    local('fab vagrant clear_db_commands:"server","dev"')
 
 
def clear_db_only():
    local('fab vagrant clear_db_commands:"no_server","dev"')
 
def clear_db_prod():
    local('fab vagrant clear_db_commands:"server","prod"')
 
 
def clear_db_only_prod():
    local('fab vagrant clear_db_commands:"no_server","prod"')
 
 
def start_dev():
    local("ssh-keygen  -R [127.0.0.1]:2222")
    local("vagrant up")
    local('fab vagrant run_dev_remote_commands:"server"')
 
 
def update_reqs():
    local("fab vagrant update_remote_venv")
 
 
def datadump():
    local("fab vagrant get_db_json")
 
 
def install_vagrant():
    local("ssh-keygen  -R [127.0.0.1]:2222")
    local("vagrant up")
    local("fab vagrant dev_commands")
 
 
'''
VM management commands
'''
 
 
def suspend():
    local("vagrant suspend")
 
 
def destroy():
    local("vagrant destroy")
 
 
def destroy_env():
    local("vagrant destroy")
    call("rm -r venv/", shell=True)
    call("rm -r .vagrant", shell=True)
 
 
def halt():
    local("vagrant halt")
 
 
'''
Commands used to manipulate your local environment if you would like
to host the dev server there rather than on the virtual machine.
'''
 
 
def clear_db_local():
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['repo_name']
    local('dropdb %s_db -h localhost -U admin' % project_name)
    local('createdb %s_db -h localhost -U admin' % project_name)
    run_dev_db_local()
 
 
def start_dev_local():
    manage_info = get_manage_path(PROJECT_DIR)
    project_path = manage_info['project_path']
    local("python %s/manage.py validate" % project_path)
    local("python %s/manage.py runserver 0.0.0.0:8080" % project_path)
 
 
def update_reqs_local():
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['project_name']
    local("pip install -r %s/requirements/production.txt" % PROJECT_DIR)
    local("python %s/%s/manage.py syncdb" %
                                            (PROJECT_DIR, project_name))
    start_dev_local()
 
 
'''
Staging/Live server commands
'''
 
 
def start_up_supervisor():
    call("sudo supervisord -c /etc/supervisor/supervisord.conf", shell=True)
 
 
def initialize_staging_server(domain):
    puppet_command = "sudo puppet apply " \
                "--modulepath=/home/apps/com.deviceforest.web/kepric_core/" \
                "puppet/modules/ puppet/manifests/development.pp"
    call(puppet_command, shell=True)
    run_real_server(domain)
 
 
def run_real_server(domain):
    '''
    There is currently no fail over strategy for this function nor any
    checks that are executed. Because of this you must ensure that
    nginx, supervisor, and gunicorn are all stopped and killed prior
    to executing this command. Please also ensure that all nginx configs
    and collectstatic files are removed that were originally generated
    by this command for the project you are using it on.
    '''
    collect_static_files()
    populate_gunicorn_script_local()
    install_supervisor()
    populate_supervisor_conig_local()
    instantiate_log_files()
    start_up_supervisor()
    install_nginx_stage(domain)
 
 
'''
Test and formatting commands
'''
 
 
def run_tests():
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['project_name']
    local("coverage run --source='.' %s/%s/manage.py test"
                                            % (PROJECT_DIR, project_name))
    local("coverage report --show-missing")
 
 
def run_test(module):
    manage_info = get_manage_path(PROJECT_DIR)
    project_name = manage_info['project_name']
    local("coverage run --source='.' %s/%s/manage.py test %s"
                                        % (PROJECT_DIR, project_name, module))
 
 
def run_lint(module):
    local("pylint --rcfile=%s/pylintconf/config.txt %s/"
                                                    % (PROJECT_DIR, module))