import socket

if socket.gethostname() == 'li323-163':
    from production import *

elif socket.gethostname() == 'web1.server.kepric.com':
    from test import *

else:
    from development import *
