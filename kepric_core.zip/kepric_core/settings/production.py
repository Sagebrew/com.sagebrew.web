# Production settings for Push Display's Omega project.
from base import *
from os import environ

DEBUG = False
TEMPLATE_DEBUG = DEBUG
ALLOWED_HOSTS = ['.pushdisplay.com', ]

DATABASES = {
    'default': {
        'ENGINE': environ.get("[[project_name_caps]]_DB_ENGINE", ''),
        'NAME': environ.get("[[project_name_caps]]_DB_NAME", ''),
        'USER': environ.get("[[project_name_caps]]_DB_USER", ''),
        'PASSWORD': environ.get("[[project_name_caps]]_DB_PASSWORD", ''),
        'HOST': '',
        'PORT': '',
    },
    'mongodb': {
            'ENGINE': 'django_mongokit.mongodb',
            'NAME': '[[project_name]]_mongo_db',
    },
}

SERVER_EMAIL = "[[project_name]]@example.com"
DEFAULT_FROM_EMAIL = "[[project_name]]@example.com"

EMAIL_HOST = environ.get("[[project_name_caps]]_EMAIL_HOST", '')
EMAIL_HOST_USER = environ.get("[[project_name_caps]]_EMAIL_USER", '')
EMAIL_HOST_PASSWORD = environ.get("[[project_name_caps]]_EMAIL_PASSWORD", '')
EMAIL_PORT = environ.get("[[project_name_caps]]_EMAIL_PORT", 587)

SECRET_KEY = environ.get("[[project_name_caps]]_SECRET_KEY", '')


