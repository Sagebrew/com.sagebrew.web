import os
import sys

from distutils.core import setup
from distutils.sysconfig import get_python_lib

from subprocess import call

overlay_warning = False
if "install" in sys.argv:
    call("sudo easy_install pip", shell=True)
    call("brew tap phinze/cask; brew install brew-cask; ", shell=True)
    lib_paths = [get_python_lib()]
    if "lib/python2.7/site-packages" not in lib_paths[0]:
        project_venv = "venv"
        virtual_exists = call("virtualenv %s" % project_venv, shell=True)
        if(virtual_exists == 1):
            pip = call(["sudo", "pip", "install", "virtualenv"], shell=True)
            if(pip == 1):
                call(["sudo", "pip", "install", "virtualenv"], shell=True)
                pip = call("sudo apt-get install python-pip",
                                                            shell=True)
                call("sudo pip install setuptools --no-use-wheel --upgrade",
                                                            shell=True)
            call(["virtualenv", project_venv])
        activate_this_file = "venv/bin/activate_this.py"
        execfile(activate_this_file, dict(__file__=activate_this_file))
    fabric_path = os.path.abspath(os.path.join(get_python_lib(), "Fabric"))
    if(os.path.exists(fabric_path)):
        overlay_warning = True
    call("ARCHFLAGS=-Wno-error=unused-command-line-argument-hard-error-in-future pip install pycrypto", shell=True)
    call(["pip", "install", "-r", "requirements/sys_utils.txt"])
#    call('vagrant plugin install vagrant-vbguest', shell=True)
    call(["fab", "install_vagrant"])


setup(
    name='dev core',
    version='0.1',
    author='Flying Frogs Team',
)

if overlay_warning:
    sys.stderr.write("""

========
WARNING!
========

You have just installed Fabric over top of an existing
installation, without removing it first. Because of this,
your install may now include extraneous files from a
previous version that have since been removed from
Django. This is known to cause a variety of problems. You
should manually remove the

%(existing_path)s

directory and re-install Fabric.

""" % {"existing_path": fabric_path})